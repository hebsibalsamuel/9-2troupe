angular.module('troupe', ['ngMaterial']);
