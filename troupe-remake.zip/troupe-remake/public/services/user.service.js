angular.module('troupe')
  .service('user', function() {
    
  });
