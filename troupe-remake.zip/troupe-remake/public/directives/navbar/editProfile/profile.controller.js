angular.module('troupe')
.controller('viewProfile', function($scope) {
  function AppCtrl($scope) {

  }
});
