angular.module('troupe')
  .controller('messageCardCtrl', function($scope) {
  });
